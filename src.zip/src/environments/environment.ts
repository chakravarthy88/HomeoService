// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyAYgkp7T_n8M4vxW7UaC4CvJJPgjDnX-gU",
    authDomain: "covidhomeoservice-85646.firebaseapp.com",
    projectId: "covidhomeoservice-85646",
    storageBucket: "covidhomeoservice-85646.appspot.com",
    messagingSenderId: "958503820256",
    appId: "1:958503820256:web:41d929d4f7c3fa0d5fe985",
    measurementId: "G-SFRK5RBKK7"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
