export interface Patient {
    uid: string;
    MailID: string;
    FirstName: string;
    LastName: string;
    Mobile: boolean;
    Age: number;
    Gender: string;
 }